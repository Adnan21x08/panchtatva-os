function renderAchievementsPage() {
  const grid = document.getElementById("achGrid");
  grid.innerHTML = DATA.achievements.map(a => `
    <div class="card">
      <div class="card-body">
        <div class="achievement-icon">${icon('award')}</div>
        <span class="tag tag-gold">${a.date}</span>
        <h3 class="card-title">${a.title}</h3>
        <p style="font-size:0.85rem;color:var(--grey-500);margin:0;">${a.organization}</p>
        <p class="card-summary">${a.description}</p>
      </div>
    </div>`).join("");

  const s = DATA.stats;
  document.getElementById("achStats").innerHTML = [
    { n: s.totalEvents, l: "Events Delivered" },
    { n: s.totalCollaborations, l: "Collaborations" },
    { n: s.totalSponsors, l: "Sponsors" },
    { n: s.totalMediaPartners, l: "Media Partners" },
  ].map(i => `<div class="stat-item"><div class="stat-num" data-count="${i.n}">0</div><div class="stat-label">${i.l}</div></div>`).join("");
}

document.addEventListener("DOMContentLoaded", () => {
  mountLayout("achievements");
  renderAchievementsPage();
  initCounters();
});
