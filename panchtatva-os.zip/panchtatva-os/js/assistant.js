const SUGGESTED_QUESTIONS = [
  "What is Nature Nexus?",
  "What workshops have been conducted?",
  "What is Eco Splash?",
  "Tell me about Panchtatva.",
  "Who can join?",
  "What activities are conducted?",
  "What happened in 2025?",
  "How many flagship events are there?",
];

function findEventMatches(query) {
  const q = query.toLowerCase().replace(/[?.,!]/g, "").trim();
  const words = q.split(/\s+/).map(w => w.replace(/[^a-z0-9]/g, "")).filter(w => w.length > 2);
  const scored = DATA.events.map(ev => {
    const hay = [ev.title, ev.theme, ev.category, ev.objective, ev.story, String(ev.year)]
      .filter(Boolean).join(" ").toLowerCase();
    let score = 0;
    if (hay.includes(q)) score += 5;
    words.forEach(w => { if (hay.includes(w)) score += 1; });
    return { ev, score };
  }).filter(s => s.score > 0).sort((a, b) => b.score - a.score);
  return scored.slice(0, 3).map(s => s.ev);
}

/**
 * Builds a compact, plain-text slice of the archive relevant to this question,
 * sent to the Gemini backend as grounding context. Keeps requests small and
 * ensures Gemini only ever sees facts, not the whole 60-event dataset every time.
 */
function buildGeminiContext(query) {
  const parts = [];

  parts.push(`SOCIETY STATS: ${DATA.stats.totalEvents} total events, ${DATA.stats.totalCollaborations} collaborations, ${DATA.stats.totalRecruitmentDrives} recruitment drives, ${DATA.stats.totalWorkshops} workshops, ${DATA.stats.totalCompetitions} competitions, ${DATA.stats.totalAwarenessCampaigns} awareness campaigns, ${DATA.stats.totalPlantationDrives} plantation drives. Session span: ${DATA.stats.sessionSpan}.`);

  const matches = findEventMatches(query);
  const yearMatch = query.match(/20\d{2}/);
  let eventPool = matches;
  if (yearMatch) {
    const yr = parseInt(yearMatch[0], 10);
    eventPool = DATA.events.filter(e => e.year === yr).slice(0, 8);
  }
  if (!eventPool.length) {
    // Fall back to flagship events so identity-style questions still have something to ground on
    eventPool = DATA.events.filter(e => e.isFlagship).slice(0, 5);
  }

  eventPool.forEach(ev => {
    parts.push(
      `EVENT: ${ev.title}\nDate: ${ev.dateDisplay}\nCategory: ${ev.category}\nObjective: ${ev.objective || "not recorded"}\nSummary: ${ev.story || "not recorded"}\nFlagship: ${ev.isFlagship ? "yes" : "no"}`
    );
  });

  parts.push(`ACHIEVEMENTS: ${DATA.achievements.map(a => `${a.title} (${a.date}, ${a.organization})`).join("; ")}`);
  parts.push(`TEAM 2025-26: ${DATA.team.map(m => `${m.name} — ${m.role}`).join("; ")}`);
  parts.push(`RECRUITMENT: Opens after the Freshers' Orientation. Follow Instagram @panchtatvazhdce for announcements.`);

  return parts.join("\n\n");
}

function answerQueryLocal(query) {
  const q = query.toLowerCase().trim();

  // Identity / general
  if (/what is panchtatva|about panchtatva|tell me about panchtatva/.test(q)) {
    return `Panchtatva is the Environmental Studies Society of Zakir Husain Delhi College (Evening), University of Delhi. Its documented archive covers ${DATA.stats.totalEvents} events across the ${DATA.stats.sessionSpan} — including plantation drives, workshops, awareness campaigns, and flagship fests like Nature Nexus and Eco Splash.`;
  }

  // Who can join
  if (/who can join|how (do|can) i join|membership|recruitment/.test(q)) {
    return `Recruitment opens after the Freshers' Orientation each session — that's confirmed by the archive's own recruitment cycle (7 recruitment drives recorded). The exact eligibility criteria for the upcoming cycle aren't in the archive yet, so I'd point you to the Recruitment page for the latest, or follow the Instagram page for the announcement.`;
  }

  // Flagship count
  if (/how many flagship|flagship events/.test(q)) {
    const flagships = DATA.events.filter(e => e.isFlagship);
    const names = [...new Set(flagships.map(e => e.title.split(/\d\.\d/)[0].trim()))];
    return `The archive identifies ${flagships.length} flagship-tagged event entries, spanning these recurring flagship series: ${names.join(", ")}.`;
  }

  // Year-based
  const yearMatch = q.match(/20\d{2}/);
  if (yearMatch && /happened|events? in/.test(q)) {
    const yr = parseInt(yearMatch[0], 10);
    const events = DATA.events.filter(e => e.year === yr).sort((a,b)=>a.dateSort.localeCompare(b.dateSort));
    if (!events.length) return `I don't have any documented events for ${yr} in the archive.`;
    return `In ${yr}, the archive documents ${events.length} events, including: ${events.slice(0,6).map(e=>e.title).join("; ")}${events.length>6 ? ", and more." : "."}`;
  }

  // Workshops
  if (/workshop/.test(q)) {
    const workshops = DATA.events.filter(e => e.category === "Workshop");
    if (!workshops.length) return "I don't have workshop records in the archive.";
    return `The archive documents ${workshops.length} workshops: ${workshops.map(e => `${e.title} (${e.dateDisplay})`).join("; ")}.`;
  }

  // Activities in general
  if (/what activities|kind of activities|activities (are )?conducted/.test(q)) {
    return `Per the archive's own category breakdown: ${DATA.stats.totalWorkshops} workshops, ${DATA.stats.totalCompetitions} competitions, ${DATA.stats.totalAwarenessCampaigns} awareness campaigns, ${DATA.stats.totalPlantationDrives} plantation drives, plus flagship fests, nature walks, and field visits.`;
  }

  // Direct event name match
  const matches = findEventMatches(query);
  if (matches.length) {
    const top = matches[0];
    let resp = `**${top.title}** (${top.dateDisplay}) — ${top.category}. `;
    resp += top.story || top.objective || "Details are limited in the archive for this event.";
    if (matches.length > 1) {
      resp += ` Related: ${matches.slice(1).map(m => m.title).join(", ")}.`;
    }
    return resp;
  }

  return "I don't have that information in Panchtatva's records. I can only answer from the society's documented archive — try asking about a specific event, category, or year, or check the Events and Journey pages directly.";
}

function pushMessage(role, text) {
  const wrap = document.getElementById("chatMessages") || document.getElementById("fullChatMessages");
  const el = document.createElement("div");
  el.className = `msg ${role === "user" ? "msg-user" : "msg-bot"}`;
  el.innerHTML = text.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  wrap.appendChild(el);
  wrap.scrollTop = wrap.scrollHeight;
  return el;
}

function showTyping() {
  const wrap = document.getElementById("chatMessages") || document.getElementById("fullChatMessages");
  const el = document.createElement("div");
  el.className = "msg msg-bot";
  el.id = "typingIndicator";
  el.innerHTML = `<span class="typing-dots"><span></span><span></span><span></span></span>`;
  wrap.appendChild(el);
  wrap.scrollTop = wrap.scrollHeight;
}

function hideTyping() {
  document.getElementById("typingIndicator")?.remove();
}

async function askGemini(question) {
  const context = buildGeminiContext(question);
  const resp = await fetch("/.netlify/functions/ask-prakriti", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, context }),
  });
  if (!resp.ok) throw new Error(`Backend responded ${resp.status}`);
  const data = await resp.json();
  if (!data.answer) throw new Error("No answer in response");
  return data.answer;
}

async function handleSend(inputEl) {
  const text = inputEl.value.trim();
  if (!text) return;
  pushMessage("user", text);
  inputEl.value = "";
  showTyping();

  try {
    const answer = await askGemini(text);
    hideTyping();
    pushMessage("bot", answer);
  } catch (err) {
    // Backend not deployed yet, no API key set, or offline — fall back to the
    // local archive-matching logic so the assistant still works, just less richly.
    hideTyping();
    pushMessage("bot", answerQueryLocal(text));
  }
}

function wireChatUI(inputId, sendId) {
  const input = document.getElementById(inputId);
  const sendBtn = document.getElementById(sendId);
  if (!input) return;
  sendBtn?.addEventListener("click", () => handleSend(input));
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") handleSend(input); });
}

function wireQuickChips(containerSelector, inputId) {
  document.querySelectorAll(containerSelector + " .quick-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      const input = document.getElementById(inputId);
      input.value = chip.textContent;
      handleSend(input);
    });
  });
}

function initAssistantWidget() {
  const launcher = document.getElementById("chatLauncher");
  const panel = document.getElementById("chatPanel");
  if (!launcher || !panel) return;
  launcher.addEventListener("click", () => panel.classList.toggle("open"));
  document.getElementById("chatClose")?.addEventListener("click", () => panel.classList.remove("open"));
  wireChatUI("chatInput", "chatSend");
  wireQuickChips("#chatPanel", "chatInput");
  pushMessage("bot", "Hi, I'm Prakriti AI 🌿 — ask me anything about Panchtatva's documented history.");
}

function initAssistantFullPage() {
  const wrap = document.getElementById("fullChatMessages");
  if (!wrap) return;
  wireChatUI("fullChatInput", "fullChatSend");
  wireQuickChips("#fullChatSuggested", "fullChatInput");
  pushMessage("bot", "Hi, I'm Prakriti AI 🌿 — your Panchtatva guide. I only answer from the society's documented archive, so if I don't know something, I'll say so rather than guess.");

  const params = new URLSearchParams(window.location.search);
  const q = params.get("q");
  if (q) {
    document.getElementById("fullChatInput").value = q;
    setTimeout(() => handleSend(document.getElementById("fullChatInput")), 400);
  }
}
